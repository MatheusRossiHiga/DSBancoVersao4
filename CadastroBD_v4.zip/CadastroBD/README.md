# Projeto Cadastro BD (Visual Studio 2022 / Windows Forms / C#)

Projeto baseado nas 3 aulas de continuação do cadastro com banco de dados:
cadastro de **Usuário** (feito pelo professor) replicado para **Cliente** e
**Fornecedor**, com tudo que foi pedido nos vídeos.

## Como abrir no Visual Studio 2022

1. Extraia o `.zip` em qualquer pasta do seu computador.
2. Abra o Visual Studio 2022 → **Abrir um projeto ou solução** → selecione
   o arquivo `CadastroBD.sln`.
3. Garanta que você tem instalada a carga de trabalho **".NET desktop
   development"** (no Visual Studio Installer, caso ainda não tenha).
4. Na primeira abertura, o Visual Studio vai restaurar automaticamente o
   pacote NuGet `Microsoft.Data.Sqlite` (precisa de internet só nesse passo).
5. Aperte **F5** (ou o botão ▶ Iniciar) para compilar e executar.

Não precisa instalar SQL Server nem configurar nada: o banco de dados é
SQLite (um único arquivo) e é criado automaticamente, junto com as 3
tabelas, na primeira execução, em `bin\Debug\net8.0-windows\Banco\CadastroBD.db`.

## O que foi implementado (igual ao das aulas)

- Tela de menu inicial com acesso ao cadastro de Usuário, Cliente e Fornecedor.
- Em cada tela: botões **Anterior, Próximo, Novo, Alterar, Salvar, Cancelar,
  Pesquisar, Imprimir e Sair**.
- Métodos `HabilitaEdicao()` e `DesabilitaEdicao()`: ao clicar em Novo/Alterar,
  os campos ficam editáveis e só Salvar/Cancelar ficam disponíveis; ao
  salvar/cancelar, volta para o modo de consulta com a navegação liberada.
- Campo Código sempre desabilitado (é gerado automaticamente) e nascendo em
  1, nunca negativo.
- Campo Senha mascarado com `PasswordChar` (mostra bolinha em vez do texto).
- `MaxLength` de cada campo batendo exatamente com o tamanho da coluna no
  banco, para não dar o erro de "valor viola o limite máximo da coluna".
- Mudança de cor (fundo azul / letra branca) ao entrar em qualquer campo de
  texto e volta ao normal ao saltextbox, usando a técnica do `sender`
  (um único método reaproveitado por todos os campos).
- Pequeno extra (não pedido em aula, fácil de remover se preferir): os
  botões Anterior/Próximo/Alterar ficam desabilitados quando não fazem
  sentido (primeiro/último registro ou lista vazia).

## O que ficou como nas aulas (ainda não implementado)

Os botões **Pesquisar** e **Imprimir** já existem e participam do
Habilita/Desabilita, mas só mostram um aviso ao serem clicados — exatamente
como o professor explicou, essa parte é uma etapa futura do projeto.

## Sobre os campos de Cliente e Fornecedor

Os vídeos não chegam a detalhar quais seriam os campos de Cliente e
Fornecedor (o professor só diz "os campos aqui são outros"). Para o
projeto funcionar de ponta a ponta, foi usado um conjunto comum de
cadastro:

- **Cliente:** Nome (60), CPF (14), Telefone (15), E-mail (50), Endereço (80)
- **Fornecedor:** Nome (60), CNPJ (18), Telefone (15), E-mail (50), Endereço (80)

Se sua atividade pede campos diferentes, é só trocar em 3 lugares: na
classe do modelo (`Modelos/Cliente.cs` ou `Fornecedor.cs`), no DAO
correspondente (`Dados/ClienteDAO.cs` ou `FornecedorDAO.cs`) e no
formulário (`FormCliente.cs`/`.Designer.cs` ou `FormFornecedor.cs`/`.Designer.cs`),
além do `CREATE TABLE` em `Dados/Conexao.cs`.

## Estrutura do projeto

```
CadastroBD.sln
CadastroBD/
  CadastroBD.csproj
  Program.cs
  FormPrincipal.cs / .Designer.cs     (menu inicial)
  FormUsuario.cs / .Designer.cs       (cadastro de usuário)
  FormCliente.cs / .Designer.cs       (cadastro de cliente)
  FormFornecedor.cs / .Designer.cs    (cadastro de fornecedor)
  Modelos/
    Usuario.cs, Cliente.cs, Fornecedor.cs
  Dados/
    Conexao.cs       (cria o banco e as tabelas)
    UsuarioDAO.cs, ClienteDAO.cs, FornecedorDAO.cs   (Listar/Inserir/Atualizar)
Banco/
  script_criacao.sql  (apenas referência — a app já cria tudo sozinha)
```
