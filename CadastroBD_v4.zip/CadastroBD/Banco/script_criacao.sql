-- Este script é apenas uma referência da estrutura usada pelo projeto.
-- A própria aplicação já cria o banco e as tabelas automaticamente na
-- primeira execução (veja CadastroBD/Dados/Conexao.cs), então você
-- NÃO precisa rodar este script manualmente.

CREATE TABLE IF NOT EXISTS Usuario (
    CodigoUsuario INTEGER PRIMARY KEY AUTOINCREMENT, -- nasce em 1 (positivo)
    NomeUsuario   TEXT NOT NULL,                      -- até 40 caracteres
    NivelUsuario  TEXT NOT NULL,                      -- sigla do nível, 1 caractere
    LoginUsuario  TEXT NOT NULL,                      -- até 15 caracteres
    SenhaUsuario  TEXT NOT NULL                        -- até 15 caracteres, exibida mascarada
);

CREATE TABLE IF NOT EXISTS Cliente (
    CodigoCliente   INTEGER PRIMARY KEY AUTOINCREMENT,
    NomeCliente     TEXT NOT NULL,   -- até 60 caracteres
    CpfCliente      TEXT,            -- até 14 caracteres
    TelefoneCliente TEXT,            -- até 15 caracteres
    EmailCliente    TEXT,            -- até 50 caracteres
    EnderecoCliente TEXT             -- até 80 caracteres
);

CREATE TABLE IF NOT EXISTS Fornecedor (
    CodigoFornecedor   INTEGER PRIMARY KEY AUTOINCREMENT,
    NomeFornecedor     TEXT NOT NULL,  -- até 60 caracteres
    CnpjFornecedor     TEXT,           -- até 18 caracteres
    TelefoneFornecedor TEXT,           -- até 15 caracteres
    EmailFornecedor    TEXT,           -- até 50 caracteres
    EnderecoFornecedor TEXT            -- até 80 caracteres
);
