using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using CadastroBD.Dados;

namespace CadastroBD
{
    public partial class FormRelatorio : Form
    {
        private string conteudoRelatorio = string.Empty;
        private string[] linhasImpressao = Array.Empty<string>();
        private int linhaAtualImpressao  = 0;

        public FormRelatorio() { InitializeComponent(); }

        private void FormRelatorio_Load(object sender, EventArgs e) => GerarRelatorio();

        private void GerarRelatorio()
        {
            var sb   = new StringBuilder();
            string tr = new string('-', 61);

            sb.AppendLine("RELATÓRIO");
            sb.AppendLine(tr);
            sb.AppendLine();

            // ── Usuários ─────────────────────────────────────────────────
            sb.AppendLine("■ USUÁRIOS");
            sb.AppendLine(tr);
            var usuarios = new UsuarioDAO().Listar();
            if (usuarios.Count == 0) { sb.AppendLine("  (nenhum usuário cadastrado)"); }
            else foreach (var u in usuarios)
            {
                sb.AppendLine($"  Código : {u.CodigoUsuario}");
                sb.AppendLine($"  Nome   : {u.NomeUsuario}");
                sb.AppendLine($"  Nível  : {u.NivelUsuario}");
                sb.AppendLine($"  Login  : {u.LoginUsuario}");
                sb.AppendLine();
            }
            sb.AppendLine();

            // ── Clientes ─────────────────────────────────────────────────
            sb.AppendLine("■ CLIENTES");
            sb.AppendLine(tr);
            var clientes = new ClienteDAO().Listar();
            if (clientes.Count == 0) { sb.AppendLine("  (nenhum cliente cadastrado)"); }
            else foreach (var c in clientes)
            {
                sb.AppendLine($"  Código   : {c.CodigoCliente}");
                sb.AppendLine($"  Nome     : {c.NomeCliente}");
                sb.AppendLine($"  CPF      : {c.CpfCliente}");
                sb.AppendLine($"  Telefone : {c.TelefoneCliente}");
                sb.AppendLine($"  E-mail   : {c.EmailCliente}");
                sb.AppendLine($"  Endereço : {c.EnderecoCliente}");
                sb.AppendLine($"  Bairro   : {c.BairroCliente}");
                sb.AppendLine($"  Cidade   : {c.CidadeCliente}");
                sb.AppendLine($"  Estado   : {c.EstadoCliente}");
                sb.AppendLine($"  CEP      : {c.CepCliente}");
                sb.AppendLine();
            }
            sb.AppendLine();

            // ── Fornecedores ─────────────────────────────────────────────
            sb.AppendLine("■ FORNECEDORES");
            sb.AppendLine(tr);
            var fornecedores = new FornecedorDAO().Listar();
            if (fornecedores.Count == 0) { sb.AppendLine("  (nenhum fornecedor cadastrado)"); }
            else foreach (var f in fornecedores)
            {
                sb.AppendLine($"  Código   : {f.CodigoFornecedor}");
                sb.AppendLine($"  Nome     : {f.NomeFornecedor}");
                sb.AppendLine($"  CNPJ     : {f.CnpjFornecedor}");
                sb.AppendLine($"  Telefone : {f.TelefoneFornecedor}");
                sb.AppendLine($"  E-mail   : {f.EmailFornecedor}");
                sb.AppendLine($"  Endereço : {f.EnderecoFornecedor}");
                sb.AppendLine($"  Bairro   : {f.BairroFornecedor}");
                sb.AppendLine($"  Cidade   : {f.CidadeFornecedor}");
                sb.AppendLine($"  Estado   : {f.EstadoFornecedor}");
                sb.AppendLine($"  CEP      : {f.CepFornecedor}");
                sb.AppendLine();
            }

            sb.AppendLine(tr);
            sb.AppendLine($"  Gerado em: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");

            conteudoRelatorio   = sb.ToString();
            rtbRelatorio.Text   = conteudoRelatorio;
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            linhasImpressao     = conteudoRelatorio.Split('\n');
            linhaAtualImpressao = 0;
            using var doc = new PrintDocument();
            doc.DocumentName = "Relatório - Sistema de Cadastro";
            doc.PrintPage   += Documento_PrintPage;
            using var prev = new PrintPreviewDialog { Document = doc, Width = 800, Height = 650 };
            prev.ShowDialog();
        }

        private void Documento_PrintPage(object sender, PrintPageEventArgs e)
        {
            var f = new Font("Courier New", 9F);
            float h = f.GetHeight(e.Graphics), x = e.MarginBounds.Left, y = e.MarginBounds.Top;
            while (linhaAtualImpressao < linhasImpressao.Length)
            {
                if (y + h > e.MarginBounds.Bottom) { e.HasMorePages = true; f.Dispose(); return; }
                e.Graphics.DrawString(linhasImpressao[linhaAtualImpressao++].TrimEnd('\r'), f, Brushes.Black, x, y);
                y += h;
            }
            e.HasMorePages = false; f.Dispose();
        }

        private void btnAtualizar_Click(object sender, EventArgs e) => GerarRelatorio();
        private void btnFechar_Click(object sender, EventArgs e)    => Close();
    }
}
