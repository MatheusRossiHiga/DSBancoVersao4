using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using CadastroBD.Dados;
using CadastroBD.Modelos;

namespace CadastroBD
{
    public partial class FormUsuario : Form
    {
        private readonly UsuarioDAO dao = new UsuarioDAO();
        private System.Collections.Generic.List<Usuario> lista = new();
        private int indiceAtual = -1;
        private string modoEdicao = string.Empty;

        // Armazena o conteúdo montado para a impressão
        private string[] linhasImpressao = Array.Empty<string>();
        private int linhaAtualImpressao = 0;

        public FormUsuario()
        {
            InitializeComponent();
        }

        private void FormUsuario_Load(object sender, EventArgs e)
        {
            txtNome.MaxLength  = 40;
            txtNivel.MaxLength = 1;
            txtLogin.MaxLength = 15;
            txtSenha.MaxLength = 15;

            txtSenha.PasswordChar = '*';
            txtCodigo.Enabled = false;

            CarregarLista();
            DesabilitaEdicao();
        }

        private void CarregarLista()
        {
            lista = dao.Listar();
            indiceAtual = lista.Count > 0 ? 0 : -1;
            MostrarRegistroAtual();
        }

        private void MostrarRegistroAtual()
        {
            if (indiceAtual >= 0 && indiceAtual < lista.Count)
            {
                Usuario u = lista[indiceAtual];
                txtCodigo.Text = u.CodigoUsuario.ToString();
                txtNome.Text   = u.NomeUsuario;
                txtNivel.Text  = u.NivelUsuario;
                txtLogin.Text  = u.LoginUsuario;
                txtSenha.Text  = u.SenhaUsuario;
            }
            else
            {
                LimparCampos();
            }

            AtualizarBotoesNavegacao();
        }

        private void LimparCampos()
        {
            txtCodigo.Text = string.Empty;
            txtNome.Text   = string.Empty;
            txtNivel.Text  = string.Empty;
            txtLogin.Text  = string.Empty;
            txtSenha.Text  = string.Empty;
        }

        private void HabilitaEdicao()
        {
            txtNome.Enabled   = true;
            txtNivel.Enabled  = true;
            txtLogin.Enabled  = true;
            txtSenha.Enabled  = true;

            btnSalvar.Enabled   = true;
            btnCancelar.Enabled = true;

            btnAnterior.Enabled  = false;
            btnProximo.Enabled   = false;
            btnNovo.Enabled      = false;
            btnAlterar.Enabled   = false;
            btnPesquisar.Enabled = false;
            btnImprimir.Enabled  = false;
            btnSair.Enabled      = false;
        }

        private void DesabilitaEdicao()
        {
            txtNome.Enabled   = false;
            txtNivel.Enabled  = false;
            txtLogin.Enabled  = false;
            txtSenha.Enabled  = false;

            btnSalvar.Enabled   = false;
            btnCancelar.Enabled = false;

            btnAnterior.Enabled  = true;
            btnProximo.Enabled   = true;
            btnNovo.Enabled      = true;
            btnAlterar.Enabled   = true;
            btnPesquisar.Enabled = true;
            btnImprimir.Enabled  = true;
            btnSair.Enabled      = true;

            AtualizarBotoesNavegacao();
        }

        private void AtualizarBotoesNavegacao()
        {
            bool temRegistro = indiceAtual >= 0 && lista.Count > 0;

            btnAnterior.Enabled = btnAnterior.Enabled && indiceAtual > 0;
            btnProximo.Enabled  = btnProximo.Enabled  && indiceAtual < lista.Count - 1;
            btnAlterar.Enabled  = btnAlterar.Enabled  && temRegistro;
            btnImprimir.Enabled = btnImprimir.Enabled && temRegistro;
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text)  ||
                string.IsNullOrWhiteSpace(txtNivel.Text) ||
                string.IsNullOrWhiteSpace(txtLogin.Text) ||
                string.IsNullOrWhiteSpace(txtSenha.Text))
            {
                MessageBox.Show("Preencha todos os campos antes de salvar.",
                    "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        // ── Navegação ───────────────────────────────────────────────────

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (indiceAtual > 0) { indiceAtual--; MostrarRegistroAtual(); }
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (indiceAtual < lista.Count - 1) { indiceAtual++; MostrarRegistroAtual(); }
        }

        // ── CRUD ────────────────────────────────────────────────────────

        private void btnNovo_Click(object sender, EventArgs e)
        {
            modoEdicao = "Novo";
            LimparCampos();
            HabilitaEdicao();
            txtNome.Focus();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (indiceAtual < 0) return;
            modoEdicao = "Alterar";
            HabilitaEdicao();
            txtNome.Focus();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            if (modoEdicao == "Novo")
            {
                var u = new Usuario
                {
                    NomeUsuario  = txtNome.Text,
                    NivelUsuario = txtNivel.Text,
                    LoginUsuario = txtLogin.Text,
                    SenhaUsuario = txtSenha.Text
                };
                int cod = dao.Inserir(u);
                CarregarLista();
                indiceAtual = lista.FindIndex(x => x.CodigoUsuario == cod);
                MostrarRegistroAtual();
            }
            else if (modoEdicao == "Alterar")
            {
                var u = new Usuario
                {
                    CodigoUsuario = int.Parse(txtCodigo.Text),
                    NomeUsuario   = txtNome.Text,
                    NivelUsuario  = txtNivel.Text,
                    LoginUsuario  = txtLogin.Text,
                    SenhaUsuario  = txtSenha.Text
                };
                dao.Atualizar(u);
                int cod = u.CodigoUsuario;
                CarregarLista();
                indiceAtual = lista.FindIndex(x => x.CodigoUsuario == cod);
                MostrarRegistroAtual();
            }

            modoEdicao = string.Empty;
            DesabilitaEdicao();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            modoEdicao = string.Empty;
            MostrarRegistroAtual();
            DesabilitaEdicao();
        }

        // ── Pesquisar ───────────────────────────────────────────────────

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A pesquisa será implementada em uma próxima etapa do projeto.",
                "Em breve", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ── Imprimir ────────────────────────────────────────────────────

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (indiceAtual < 0 || indiceAtual >= lista.Count)
            {
                MessageBox.Show("Nenhum registro selecionado para imprimir.",
                    "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Usuario u = lista[indiceAtual];
            string linha = new string('-', 45);

            var sb = new StringBuilder();
            sb.AppendLine("RELATÓRIO");
            sb.AppendLine(linha);
            sb.AppendLine();
            sb.AppendLine("■ USUÁRIO");
            sb.AppendLine(linha);
            sb.AppendLine($"  Código : {u.CodigoUsuario}");
            sb.AppendLine($"  Nome   : {u.NomeUsuario}");
            sb.AppendLine($"  Nível  : {u.NivelUsuario}");
            sb.AppendLine($"  Login  : {u.LoginUsuario}");
            // Senha omitida na impressão
            sb.AppendLine();
            sb.AppendLine(linha);
            sb.AppendLine($"  Impresso em: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");

            linhasImpressao     = sb.ToString().Split('\n');
            linhaAtualImpressao = 0;

            using var documento = new PrintDocument();
            documento.DocumentName = $"Usuário - {u.NomeUsuario}";
            documento.PrintPage   += Documento_PrintPage;

            using var preview = new PrintPreviewDialog();
            preview.Document = documento;
            preview.Width    = 700;
            preview.Height   = 550;
            preview.ShowDialog();
        }

        private void Documento_PrintPage(object sender, PrintPageEventArgs e)
        {
            var fonte = new Font("Courier New", 10F);
            float alturaLinha = fonte.GetHeight(e.Graphics);
            float x = e.MarginBounds.Left;
            float y = e.MarginBounds.Top;

            while (linhaAtualImpressao < linhasImpressao.Length)
            {
                if (y + alturaLinha > e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    fonte.Dispose();
                    return;
                }
                e.Graphics.DrawString(
                    linhasImpressao[linhaAtualImpressao].TrimEnd('\r'),
                    fonte, Brushes.Black, x, y);
                y += alturaLinha;
                linhaAtualImpressao++;
            }
            e.HasMorePages = false;
            fonte.Dispose();
        }

        // ── Sair ────────────────────────────────────────────────────────

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ── Efeito de foco nos campos (técnica do sender) ────────────────

        private void Campo_Enter(object sender, EventArgs e)
        {
            var campo = (TextBox)sender;
            campo.ForeColor = Color.White;
            campo.BackColor = Color.Blue;
        }

        private void Campo_Leave(object sender, EventArgs e)
        {
            var campo = (TextBox)sender;
            campo.ForeColor = Color.Black;
            campo.BackColor = Color.White;
        }
    }
}
