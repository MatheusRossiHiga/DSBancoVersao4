using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using CadastroBD.Dados;
using CadastroBD.Modelos;

namespace CadastroBD
{
    public partial class FormFornecedor : Form
    {
        private readonly FornecedorDAO dao = new FornecedorDAO();
        private System.Collections.Generic.List<Fornecedor> lista = new();
        private int indiceAtual = -1;
        private string modoEdicao = string.Empty;
        private string[] linhasImpressao = Array.Empty<string>();
        private int linhaAtualImpressao = 0;

        public FormFornecedor() { InitializeComponent(); }

        private void FormFornecedor_Load(object sender, EventArgs e)
        {
            txtNome.MaxLength     = 60;
            txtCnpj.MaxLength     = 18;
            txtTelefone.MaxLength = 15;
            txtEmail.MaxLength    = 50;
            txtEndereco.MaxLength = 80;
            txtBairro.MaxLength   = 40;
            txtCidade.MaxLength   = 50;
            txtEstado.MaxLength   = 2;
            txtCep.MaxLength      = 9;
            txtCodigo.Enabled     = false;
            CarregarLista();
            DesabilitaEdicao();
        }

        private void CarregarLista()
        {
            lista = dao.Listar();
            indiceAtual = lista.Count > 0 ? 0 : -1;
            MostrarRegistroAtual();
        }

        private void MostrarRegistroAtual()
        {
            if (indiceAtual >= 0 && indiceAtual < lista.Count)
            {
                var f = lista[indiceAtual];
                txtCodigo.Text   = f.CodigoFornecedor.ToString();
                txtNome.Text     = f.NomeFornecedor;
                txtCnpj.Text     = f.CnpjFornecedor;
                txtTelefone.Text = f.TelefoneFornecedor;
                txtEmail.Text    = f.EmailFornecedor;
                txtEndereco.Text = f.EnderecoFornecedor;
                txtBairro.Text   = f.BairroFornecedor;
                txtCidade.Text   = f.CidadeFornecedor;
                txtEstado.Text   = f.EstadoFornecedor;
                txtCep.Text      = f.CepFornecedor;
            }
            else LimparCampos();
            AtualizarBotoesNavegacao();
        }

        private void LimparCampos()
        {
            txtCodigo.Text = txtNome.Text = txtCnpj.Text = txtTelefone.Text =
            txtEmail.Text  = txtEndereco.Text = txtBairro.Text =
            txtCidade.Text = txtEstado.Text = txtCep.Text = string.Empty;
        }

        private void HabilitaEdicao()
        {
            foreach (TextBox t in new[]{txtNome,txtCnpj,txtTelefone,txtEmail,
                                         txtEndereco,txtBairro,txtCidade,txtEstado,txtCep})
                t.Enabled = true;
            btnSalvar.Enabled = btnCancelar.Enabled = true;
            btnAnterior.Enabled = btnProximo.Enabled = btnNovo.Enabled =
            btnAlterar.Enabled  = btnPesquisar.Enabled = btnImprimir.Enabled =
            btnSair.Enabled     = false;
        }

        private void DesabilitaEdicao()
        {
            foreach (TextBox t in new[]{txtNome,txtCnpj,txtTelefone,txtEmail,
                                         txtEndereco,txtBairro,txtCidade,txtEstado,txtCep})
                t.Enabled = false;
            btnSalvar.Enabled = btnCancelar.Enabled = false;
            btnAnterior.Enabled = btnProximo.Enabled = btnNovo.Enabled =
            btnAlterar.Enabled  = btnPesquisar.Enabled = btnImprimir.Enabled =
            btnSair.Enabled     = true;
            AtualizarBotoesNavegacao();
        }

        private void AtualizarBotoesNavegacao()
        {
            bool tem = indiceAtual >= 0 && lista.Count > 0;
            btnAnterior.Enabled = btnAnterior.Enabled && indiceAtual > 0;
            btnProximo.Enabled  = btnProximo.Enabled  && indiceAtual < lista.Count - 1;
            btnAlterar.Enabled  = btnAlterar.Enabled  && tem;
            btnImprimir.Enabled = btnImprimir.Enabled && tem;
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Preencha pelo menos o nome do fornecedor antes de salvar.",
                    "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        { if (indiceAtual > 0) { indiceAtual--; MostrarRegistroAtual(); } }

        private void btnProximo_Click(object sender, EventArgs e)
        { if (indiceAtual < lista.Count - 1) { indiceAtual++; MostrarRegistroAtual(); } }

        private void btnNovo_Click(object sender, EventArgs e)
        { modoEdicao = "Novo"; LimparCampos(); HabilitaEdicao(); txtNome.Focus(); }

        private void btnAlterar_Click(object sender, EventArgs e)
        { if (indiceAtual < 0) return; modoEdicao = "Alterar"; HabilitaEdicao(); txtNome.Focus(); }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;
            var f = new Fornecedor {
                NomeFornecedor     = txtNome.Text,     CnpjFornecedor     = txtCnpj.Text,
                TelefoneFornecedor = txtTelefone.Text, EmailFornecedor    = txtEmail.Text,
                EnderecoFornecedor = txtEndereco.Text, BairroFornecedor   = txtBairro.Text,
                CidadeFornecedor   = txtCidade.Text,   EstadoFornecedor   = txtEstado.Text,
                CepFornecedor      = txtCep.Text
            };
            if (modoEdicao == "Novo")
            {
                int cod = dao.Inserir(f);
                CarregarLista();
                indiceAtual = lista.FindIndex(x => x.CodigoFornecedor == cod);
            }
            else
            {
                f.CodigoFornecedor = int.Parse(txtCodigo.Text);
                dao.Atualizar(f);
                int cod = f.CodigoFornecedor;
                CarregarLista();
                indiceAtual = lista.FindIndex(x => x.CodigoFornecedor == cod);
            }
            MostrarRegistroAtual();
            modoEdicao = string.Empty;
            DesabilitaEdicao();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        { modoEdicao = string.Empty; MostrarRegistroAtual(); DesabilitaEdicao(); }

        private void btnPesquisar_Click(object sender, EventArgs e)
            => MessageBox.Show("A pesquisa será implementada em uma próxima etapa.",
               "Em breve", MessageBoxButtons.OK, MessageBoxIcon.Information);

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (indiceAtual < 0 || indiceAtual >= lista.Count) return;
            var f = lista[indiceAtual];
            string tr = new string('-', 45);
            var sb = new StringBuilder();
            sb.AppendLine("RELATÓRIO");
            sb.AppendLine(tr);
            sb.AppendLine();
            sb.AppendLine("■ FORNECEDOR");
            sb.AppendLine(tr);
            sb.AppendLine($"  Código   : {f.CodigoFornecedor}");
            sb.AppendLine($"  Nome     : {f.NomeFornecedor}");
            sb.AppendLine($"  CNPJ     : {f.CnpjFornecedor}");
            sb.AppendLine($"  Telefone : {f.TelefoneFornecedor}");
            sb.AppendLine($"  E-mail   : {f.EmailFornecedor}");
            sb.AppendLine($"  Endereço : {f.EnderecoFornecedor}");
            sb.AppendLine($"  Bairro   : {f.BairroFornecedor}");
            sb.AppendLine($"  Cidade   : {f.CidadeFornecedor}");
            sb.AppendLine($"  Estado   : {f.EstadoFornecedor}");
            sb.AppendLine($"  CEP      : {f.CepFornecedor}");
            sb.AppendLine();
            sb.AppendLine(tr);
            sb.AppendLine($"  Impresso em: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");

            linhasImpressao = sb.ToString().Split('\n');
            linhaAtualImpressao = 0;
            using var doc = new PrintDocument();
            doc.DocumentName = $"Fornecedor - {f.NomeFornecedor}";
            doc.PrintPage   += PrintPage;
            using var prev = new PrintPreviewDialog { Document = doc, Width = 700, Height = 550 };
            prev.ShowDialog();
        }

        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            var ft = new Font("Courier New", 10F);
            float h = ft.GetHeight(e.Graphics), x = e.MarginBounds.Left, y = e.MarginBounds.Top;
            while (linhaAtualImpressao < linhasImpressao.Length)
            {
                if (y + h > e.MarginBounds.Bottom) { e.HasMorePages = true; ft.Dispose(); return; }
                e.Graphics.DrawString(linhasImpressao[linhaAtualImpressao++].TrimEnd('\r'), ft, Brushes.Black, x, y);
                y += h;
            }
            e.HasMorePages = false; ft.Dispose();
        }

        private void btnSair_Click(object sender, EventArgs e) => Close();

        private void Campo_Enter(object sender, EventArgs e)
        { var t = (TextBox)sender; t.ForeColor = Color.White; t.BackColor = Color.Blue; }

        private void Campo_Leave(object sender, EventArgs e)
        { var t = (TextBox)sender; t.ForeColor = Color.Black; t.BackColor = Color.White; }
    }
}
