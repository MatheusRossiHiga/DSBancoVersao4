namespace CadastroBD
{
    partial class FormPrincipal
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.MenuStrip menuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem mnuCadastro;
        private System.Windows.Forms.ToolStripMenuItem mnuUsuario;
        private System.Windows.Forms.ToolStripMenuItem mnuCliente;
        private System.Windows.Forms.ToolStripMenuItem mnuFornecedor;
        private System.Windows.Forms.ToolStripMenuItem mnuRelatorio;
        private System.Windows.Forms.ToolStripMenuItem mnuSair;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuPrincipal  = new System.Windows.Forms.MenuStrip();
            this.mnuCadastro    = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUsuario     = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCliente     = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFornecedor  = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRelatorio   = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSair        = new System.Windows.Forms.ToolStripMenuItem();

            this.menuPrincipal.SuspendLayout();
            this.SuspendLayout();

            //
            // mnuUsuario / mnuCliente / mnuFornecedor — as 3 opções dentro de "Cadastro"
            //
            this.mnuUsuario.Text = "Usuário";
            this.mnuUsuario.Click += new System.EventHandler(this.mnuUsuario_Click);

            this.mnuCliente.Text = "Cliente";
            this.mnuCliente.Click += new System.EventHandler(this.mnuCliente_Click);

            this.mnuFornecedor.Text = "Fornecedor";
            this.mnuFornecedor.Click += new System.EventHandler(this.mnuFornecedor_Click);

            //
            // mnuCadastro — menu principal "Cadastro" com as 3 opções acima
            //
            this.mnuCadastro.Text = "Cadastro";
            this.mnuCadastro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuUsuario,
                this.mnuCliente,
                this.mnuFornecedor});

            //
            // mnuRelatorio
            //
            this.mnuRelatorio.Text = "Relatório";
            this.mnuRelatorio.Click += new System.EventHandler(this.mnuRelatorio_Click);

            //
            // mnuSair
            //
            this.mnuSair.Text = "Sair";
            this.mnuSair.Click += new System.EventHandler(this.mnuSair_Click);

            //
            // menuPrincipal
            //
            this.menuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuCadastro,
                this.mnuRelatorio,
                this.mnuSair});
            this.menuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.menuPrincipal.Size = new System.Drawing.Size(420, 24);

            //
            // FormPrincipal
            //
            this.ClientSize = new System.Drawing.Size(420, 260);
            this.Controls.Add(this.menuPrincipal);
            this.MainMenuStrip = this.menuPrincipal;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Principal";

            this.menuPrincipal.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
