namespace CadastroBD.Modelos
{
    public class Cliente
    {
        public int    CodigoCliente   { get; set; }
        public string NomeCliente     { get; set; } = string.Empty;
        public string CpfCliente      { get; set; } = string.Empty;
        public string TelefoneCliente { get; set; } = string.Empty;
        public string EmailCliente    { get; set; } = string.Empty;
        public string EnderecoCliente { get; set; } = string.Empty;
        public string BairroCliente   { get; set; } = string.Empty;
        public string CidadeCliente   { get; set; } = string.Empty;
        public string EstadoCliente   { get; set; } = string.Empty;
        public string CepCliente      { get; set; } = string.Empty;
    }
}
