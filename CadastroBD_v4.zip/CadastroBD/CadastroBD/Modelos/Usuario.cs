namespace CadastroBD.Modelos
{
    /// <summary>
    /// Representa o objeto do mundo real "Usuário" do sistema,
    /// com os mesmos campos definidos no banco de dados nas aulas:
    /// Código (auto incremento), Nome (até 40), Nível (1 caractere),
    /// Login (até 15) e Senha (até 15).
    /// </summary>
    public class Usuario
    {
        public int CodigoUsuario { get; set; }
        public string NomeUsuario { get; set; } = string.Empty;
        public string NivelUsuario { get; set; } = string.Empty;
        public string LoginUsuario { get; set; } = string.Empty;
        public string SenhaUsuario { get; set; } = string.Empty;
    }
}
