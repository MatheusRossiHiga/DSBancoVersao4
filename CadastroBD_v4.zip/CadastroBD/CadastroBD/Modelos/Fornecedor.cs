namespace CadastroBD.Modelos
{
    public class Fornecedor
    {
        public int    CodigoFornecedor   { get; set; }
        public string NomeFornecedor     { get; set; } = string.Empty;
        public string CnpjFornecedor     { get; set; } = string.Empty;
        public string TelefoneFornecedor { get; set; } = string.Empty;
        public string EmailFornecedor    { get; set; } = string.Empty;
        public string EnderecoFornecedor { get; set; } = string.Empty;
        public string BairroFornecedor   { get; set; } = string.Empty;
        public string CidadeFornecedor   { get; set; } = string.Empty;
        public string EstadoFornecedor   { get; set; } = string.Empty;
        public string CepFornecedor      { get; set; } = string.Empty;
    }
}
