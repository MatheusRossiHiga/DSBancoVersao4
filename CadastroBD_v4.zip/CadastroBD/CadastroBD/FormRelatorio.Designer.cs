namespace CadastroBD
{
    partial class FormRelatorio
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.RichTextBox rtbRelatorio;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label lblTitulo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitulo    = new System.Windows.Forms.Label();
            this.rtbRelatorio = new System.Windows.Forms.RichTextBox();
            this.btnImprimir  = new System.Windows.Forms.Button();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.btnFechar    = new System.Windows.Forms.Button();

            //
            // lblTitulo
            //
            this.lblTitulo.AutoSize = false;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.Location = new System.Drawing.Point(12, 10);
            this.lblTitulo.Size = new System.Drawing.Size(660, 32);
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitulo.Text = "Relatório Geral de Cadastros";

            //
            // rtbRelatorio — área de texto somente-leitura que exibe o relatório
            //
            this.rtbRelatorio.Font = new System.Drawing.Font("Courier New", 9.5F);
            this.rtbRelatorio.Location = new System.Drawing.Point(12, 52);
            this.rtbRelatorio.Size = new System.Drawing.Size(660, 430);
            this.rtbRelatorio.ReadOnly = true;
            this.rtbRelatorio.BackColor = System.Drawing.Color.White;
            this.rtbRelatorio.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbRelatorio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            //
            // btnAtualizar
            //
            this.btnAtualizar.Location = new System.Drawing.Point(12, 498);
            this.btnAtualizar.Size = new System.Drawing.Size(110, 34);
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);

            //
            // btnImprimir
            //
            this.btnImprimir.Location = new System.Drawing.Point(460, 498);
            this.btnImprimir.Size = new System.Drawing.Size(100, 34);
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);

            //
            // btnFechar
            //
            this.btnFechar.Location = new System.Drawing.Point(572, 498);
            this.btnFechar.Size = new System.Drawing.Size(100, 34);
            this.btnFechar.Text = "Fechar";
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);

            //
            // FormRelatorio
            //
            this.ClientSize = new System.Drawing.Size(684, 546);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.rtbRelatorio);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.btnFechar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Relatório";
            this.Load += new System.EventHandler(this.FormRelatorio_Load);
        }
    }
}
