namespace CadastroBD
{
    partial class FormFornecedor
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblCodigo, lblNome, lblCnpj, lblTelefone;
        private System.Windows.Forms.Label lblEmail, lblEndereco, lblBairro, lblCidade;
        private System.Windows.Forms.Label lblEstado, lblCep;

        private System.Windows.Forms.TextBox txtCodigo, txtNome, txtCnpj, txtTelefone;
        private System.Windows.Forms.TextBox txtEmail, txtEndereco, txtBairro, txtCidade;
        private System.Windows.Forms.TextBox txtEstado, txtCep;

        private System.Windows.Forms.Button btnAnterior, btnProximo, btnNovo, btnAlterar;
        private System.Windows.Forms.Button btnSalvar, btnCancelar, btnPesquisar;
        private System.Windows.Forms.Button btnImprimir, btnSair;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblCodigo   = new System.Windows.Forms.Label();
            lblNome     = new System.Windows.Forms.Label();
            lblCnpj     = new System.Windows.Forms.Label();
            lblTelefone = new System.Windows.Forms.Label();
            lblEmail    = new System.Windows.Forms.Label();
            lblEndereco = new System.Windows.Forms.Label();
            lblBairro   = new System.Windows.Forms.Label();
            lblCidade   = new System.Windows.Forms.Label();
            lblEstado   = new System.Windows.Forms.Label();
            lblCep      = new System.Windows.Forms.Label();

            txtCodigo   = new System.Windows.Forms.TextBox();
            txtNome     = new System.Windows.Forms.TextBox();
            txtCnpj     = new System.Windows.Forms.TextBox();
            txtTelefone = new System.Windows.Forms.TextBox();
            txtEmail    = new System.Windows.Forms.TextBox();
            txtEndereco = new System.Windows.Forms.TextBox();
            txtBairro   = new System.Windows.Forms.TextBox();
            txtCidade   = new System.Windows.Forms.TextBox();
            txtEstado   = new System.Windows.Forms.TextBox();
            txtCep      = new System.Windows.Forms.TextBox();

            btnAnterior  = new System.Windows.Forms.Button();
            btnProximo   = new System.Windows.Forms.Button();
            btnNovo      = new System.Windows.Forms.Button();
            btnAlterar   = new System.Windows.Forms.Button();
            btnSalvar    = new System.Windows.Forms.Button();
            btnCancelar  = new System.Windows.Forms.Button();
            btnPesquisar = new System.Windows.Forms.Button();
            btnImprimir  = new System.Windows.Forms.Button();
            btnSair      = new System.Windows.Forms.Button();

            int lx = 20, tx = 155, tw = 360, lh = 23, row = 37;

            SetLabel(lblCodigo,   "Código:",    lx, 18,        lh);
            SetTxt(txtCodigo,     tx, 15,        tw, false);

            SetLabel(lblNome,     "Nome:",      lx, 18+row,    lh);
            SetTxt(txtNome,       tx, 15+row,    tw, true);

            SetLabel(lblCnpj,     "CNPJ:",      lx, 18+row*2,  lh);
            SetTxt(txtCnpj,       tx, 15+row*2,  tw, true);

            SetLabel(lblTelefone, "Telefone:",  lx, 18+row*3,  lh);
            SetTxt(txtTelefone,   tx, 15+row*3,  tw, true);

            SetLabel(lblEmail,    "E-mail:",    lx, 18+row*4,  lh);
            SetTxt(txtEmail,      tx, 15+row*4,  tw, true);

            SetLabel(lblEndereco, "Endereço:",  lx, 18+row*5,  lh);
            SetTxt(txtEndereco,   tx, 15+row*5,  tw, true);

            SetLabel(lblBairro,   "Bairro:",    lx, 18+row*6,  lh);
            SetTxt(txtBairro,     tx, 15+row*6,  tw, true);

            // Linha 7 — Cidade / UF / CEP
            SetLabel(lblCidade, "Cidade:", lx, 18+row*7, lh);
            txtCidade.Location = new System.Drawing.Point(tx, 15+row*7);
            txtCidade.Size     = new System.Drawing.Size(180, 23);
            txtCidade.Enabled  = false;
            txtCidade.Enter   += new System.EventHandler(this.Campo_Enter);
            txtCidade.Leave   += new System.EventHandler(this.Campo_Leave);

            SetLabel(lblEstado, "UF:", tx+190, 18+row*7, lh);
            txtEstado.Location = new System.Drawing.Point(tx+220, 15+row*7);
            txtEstado.Size     = new System.Drawing.Size(35, 23);
            txtEstado.Enabled  = false;
            txtEstado.Enter   += new System.EventHandler(this.Campo_Enter);
            txtEstado.Leave   += new System.EventHandler(this.Campo_Leave);

            SetLabel(lblCep, "CEP:", tx+265, 18+row*7, lh);
            txtCep.Location = new System.Drawing.Point(tx+295, 15+row*7);
            txtCep.Size     = new System.Drawing.Size(65, 23);
            txtCep.Enabled  = false;
            txtCep.Enter   += new System.EventHandler(this.Campo_Enter);
            txtCep.Leave   += new System.EventHandler(this.Campo_Leave);

            int by1 = 15+row*8+10, by2 = by1+38, bw = 95, bh = 32;
            SetBtn(btnAnterior,  "Anterior",  lx,          by1, bw, bh, this.btnAnterior_Click);
            SetBtn(btnProximo,   "Próximo",   lx+bw+5,     by1, bw, bh, this.btnProximo_Click);
            SetBtn(btnNovo,      "Novo",      lx+(bw+5)*2, by1, bw, bh, this.btnNovo_Click);
            SetBtn(btnAlterar,   "Alterar",   lx+(bw+5)*3, by1, bw, bh, this.btnAlterar_Click);
            SetBtn(btnSalvar,    "Salvar",    lx+(bw+5)*4, by1, bw, bh, this.btnSalvar_Click);
            SetBtn(btnCancelar,  "Cancelar",  lx,          by2, bw, bh, this.btnCancelar_Click);
            SetBtn(btnPesquisar, "Pesquisar", lx+bw+5,     by2, bw, bh, this.btnPesquisar_Click);
            SetBtn(btnImprimir,  "Imprimir",  lx+(bw+5)*2, by2, bw, bh, this.btnImprimir_Click);
            SetBtn(btnSair,      "Sair",      lx+(bw+5)*3, by2, bw, bh, this.btnSair_Click);

            this.ClientSize = new System.Drawing.Size(545, by2+bh+16);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblCodigo,lblNome,lblCnpj,lblTelefone,lblEmail,
                lblEndereco,lblBairro,lblCidade,lblEstado,lblCep,
                txtCodigo,txtNome,txtCnpj,txtTelefone,txtEmail,
                txtEndereco,txtBairro,txtCidade,txtEstado,txtCep,
                btnAnterior,btnProximo,btnNovo,btnAlterar,btnSalvar,
                btnCancelar,btnPesquisar,btnImprimir,btnSair
            });
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text            = "Cadastro de Fornecedor";
            this.Load           += new System.EventHandler(this.FormFornecedor_Load);
        }

        private void SetLabel(System.Windows.Forms.Label l, string txt, int x, int y, int h)
        { l.Text = txt; l.Location = new System.Drawing.Point(x,y); l.Size = new System.Drawing.Size(130,h); }

        private void SetTxt(System.Windows.Forms.TextBox t, int x, int y, int w, bool ev)
        {
            t.Location = new System.Drawing.Point(x,y);
            t.Size     = new System.Drawing.Size(w,23);
            t.Enabled  = false;
            if (ev) { t.Enter += new System.EventHandler(this.Campo_Enter);
                      t.Leave += new System.EventHandler(this.Campo_Leave); }
        }

        private void SetBtn(System.Windows.Forms.Button b, string txt, int x, int y, int w, int h,
                            System.EventHandler click)
        { b.Text=txt; b.Location=new System.Drawing.Point(x,y); b.Size=new System.Drawing.Size(w,h); b.Click+=click; }
    }
}
