using System;
using System.Windows.Forms;
using CadastroBD.Dados;

namespace CadastroBD
{
    internal static class Program
    {
        /// <summary>
        /// Ponto de entrada principal da aplicação.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Garante que o arquivo de banco de dados e as tabelas (Usuario, Cliente,
            // Fornecedor) existam antes de qualquer tela ser aberta.
            Conexao.InicializarBanco();

            ApplicationConfiguration.Initialize();
            Application.Run(new FormPrincipal());
        }
    }
}
