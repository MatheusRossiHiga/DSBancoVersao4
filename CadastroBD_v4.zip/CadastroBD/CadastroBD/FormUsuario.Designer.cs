namespace CadastroBD
{
    partial class FormUsuario
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblCodigo;
        private Label lblNome;
        private Label lblNivel;
        private Label lblLogin;
        private Label lblSenha;

        private TextBox txtCodigo;
        private TextBox txtNome;
        private TextBox txtNivel;
        private TextBox txtLogin;
        private TextBox txtSenha;

        private Button btnAnterior;
        private Button btnProximo;
        private Button btnNovo;
        private Button btnAlterar;
        private Button btnSalvar;
        private Button btnCancelar;
        private Button btnPesquisar;
        private Button btnImprimir;
        private Button btnSair;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblCodigo = new Label();
            this.lblNome = new Label();
            this.lblNivel = new Label();
            this.lblLogin = new Label();
            this.lblSenha = new Label();

            this.txtCodigo = new TextBox();
            this.txtNome = new TextBox();
            this.txtNivel = new TextBox();
            this.txtLogin = new TextBox();
            this.txtSenha = new TextBox();

            this.btnAnterior = new Button();
            this.btnProximo = new Button();
            this.btnNovo = new Button();
            this.btnAlterar = new Button();
            this.btnSalvar = new Button();
            this.btnCancelar = new Button();
            this.btnPesquisar = new Button();
            this.btnImprimir = new Button();
            this.btnSair = new Button();

            //
            // Labels
            //
            this.lblCodigo.Location = new System.Drawing.Point(20, 20);
            this.lblCodigo.Size = new System.Drawing.Size(110, 23);
            this.lblCodigo.Text = "Código:";

            this.lblNome.Location = new System.Drawing.Point(20, 60);
            this.lblNome.Size = new System.Drawing.Size(110, 23);
            this.lblNome.Text = "Nome:";

            this.lblNivel.Location = new System.Drawing.Point(20, 100);
            this.lblNivel.Size = new System.Drawing.Size(110, 23);
            this.lblNivel.Text = "Nível (sigla):";

            this.lblLogin.Location = new System.Drawing.Point(20, 140);
            this.lblLogin.Size = new System.Drawing.Size(110, 23);
            this.lblLogin.Text = "Login:";

            this.lblSenha.Location = new System.Drawing.Point(20, 180);
            this.lblSenha.Size = new System.Drawing.Size(110, 23);
            this.lblSenha.Text = "Senha:";

            //
            // TextBoxes
            //
            this.txtCodigo.Location = new System.Drawing.Point(150, 17);
            this.txtCodigo.Size = new System.Drawing.Size(250, 23);

            this.txtNome.Location = new System.Drawing.Point(150, 57);
            this.txtNome.Size = new System.Drawing.Size(250, 23);
            this.txtNome.Enter += new System.EventHandler(this.Campo_Enter);
            this.txtNome.Leave += new System.EventHandler(this.Campo_Leave);

            this.txtNivel.Location = new System.Drawing.Point(150, 97);
            this.txtNivel.Size = new System.Drawing.Size(250, 23);
            this.txtNivel.Enter += new System.EventHandler(this.Campo_Enter);
            this.txtNivel.Leave += new System.EventHandler(this.Campo_Leave);

            this.txtLogin.Location = new System.Drawing.Point(150, 137);
            this.txtLogin.Size = new System.Drawing.Size(250, 23);
            this.txtLogin.Enter += new System.EventHandler(this.Campo_Enter);
            this.txtLogin.Leave += new System.EventHandler(this.Campo_Leave);

            this.txtSenha.Location = new System.Drawing.Point(150, 177);
            this.txtSenha.Size = new System.Drawing.Size(250, 23);
            this.txtSenha.Enter += new System.EventHandler(this.Campo_Enter);
            this.txtSenha.Leave += new System.EventHandler(this.Campo_Leave);

            //
            // Botões — linha 1
            //
            this.btnAnterior.Location = new System.Drawing.Point(20, 230);
            this.btnAnterior.Size = new System.Drawing.Size(90, 32);
            this.btnAnterior.Text = "Anterior";
            this.btnAnterior.Click += new System.EventHandler(this.btnAnterior_Click);

            this.btnProximo.Location = new System.Drawing.Point(120, 230);
            this.btnProximo.Size = new System.Drawing.Size(90, 32);
            this.btnProximo.Text = "Próximo";
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);

            this.btnNovo.Location = new System.Drawing.Point(220, 230);
            this.btnNovo.Size = new System.Drawing.Size(90, 32);
            this.btnNovo.Text = "Novo";
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);

            this.btnAlterar.Location = new System.Drawing.Point(320, 230);
            this.btnAlterar.Size = new System.Drawing.Size(90, 32);
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);

            this.btnSalvar.Location = new System.Drawing.Point(420, 230);
            this.btnSalvar.Size = new System.Drawing.Size(90, 32);
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);

            //
            // Botões — linha 2
            //
            this.btnCancelar.Location = new System.Drawing.Point(20, 270);
            this.btnCancelar.Size = new System.Drawing.Size(90, 32);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);

            this.btnPesquisar.Location = new System.Drawing.Point(120, 270);
            this.btnPesquisar.Size = new System.Drawing.Size(90, 32);
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);

            this.btnImprimir.Location = new System.Drawing.Point(220, 270);
            this.btnImprimir.Size = new System.Drawing.Size(90, 32);
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);

            this.btnSair.Location = new System.Drawing.Point(320, 270);
            this.btnSair.Size = new System.Drawing.Size(90, 32);
            this.btnSair.Text = "Sair";
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);

            //
            // FormUsuario
            //
            this.ClientSize = new System.Drawing.Size(560, 330);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblNivel);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtNivel);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.btnAnterior);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.btnNovo);
            this.Controls.Add(this.btnAlterar);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.btnSair);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Usuário";
            this.Load += new System.EventHandler(this.FormUsuario_Load);
        }
    }
}
