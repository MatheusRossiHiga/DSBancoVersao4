using System;
using System.Windows.Forms;

namespace CadastroBD
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        // ── Menu "Cadastro" → Usuário / Cliente / Fornecedor ──────────────

        private void mnuUsuario_Click(object sender, EventArgs e)
        {
            using var tela = new FormUsuario();
            tela.ShowDialog();
        }

        private void mnuCliente_Click(object sender, EventArgs e)
        {
            using var tela = new FormCliente();
            tela.ShowDialog();
        }

        private void mnuFornecedor_Click(object sender, EventArgs e)
        {
            using var tela = new FormFornecedor();
            tela.ShowDialog();
        }

        // ── Demais itens do menu ──────────────────────────────────────────

        private void mnuRelatorio_Click(object sender, EventArgs e)
        {
            using var tela = new FormRelatorio();
            tela.ShowDialog();
        }

        private void mnuSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
