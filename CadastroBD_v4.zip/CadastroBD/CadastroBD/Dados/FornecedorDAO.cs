using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using CadastroBD.Modelos;

namespace CadastroBD.Dados
{
    public class FornecedorDAO
    {
        public List<Fornecedor> Listar()
        {
            var lista = new List<Fornecedor>();
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                SELECT CodigoFornecedor, NomeFornecedor, CnpjFornecedor, TelefoneFornecedor,
                       EmailFornecedor, EnderecoFornecedor, BairroFornecedor, CidadeFornecedor,
                       EstadoFornecedor, CepFornecedor
                FROM Fornecedor ORDER BY CodigoFornecedor;";
            using var r = cmd.ExecuteReader();
            while (r.Read())
                lista.Add(new Fornecedor {
                    CodigoFornecedor   = r.GetInt32(0),
                    NomeFornecedor     = r.GetString(1),
                    CnpjFornecedor     = r.IsDBNull(2) ? "" : r.GetString(2),
                    TelefoneFornecedor = r.IsDBNull(3) ? "" : r.GetString(3),
                    EmailFornecedor    = r.IsDBNull(4) ? "" : r.GetString(4),
                    EnderecoFornecedor = r.IsDBNull(5) ? "" : r.GetString(5),
                    BairroFornecedor   = r.IsDBNull(6) ? "" : r.GetString(6),
                    CidadeFornecedor   = r.IsDBNull(7) ? "" : r.GetString(7),
                    EstadoFornecedor   = r.IsDBNull(8) ? "" : r.GetString(8),
                    CepFornecedor      = r.IsDBNull(9) ? "" : r.GetString(9)
                });
            return lista;
        }

        public int Inserir(Fornecedor f)
        {
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO Fornecedor
                    (NomeFornecedor, CnpjFornecedor, TelefoneFornecedor, EmailFornecedor,
                     EnderecoFornecedor, BairroFornecedor, CidadeFornecedor, EstadoFornecedor, CepFornecedor)
                VALUES
                    ($nome,$cnpj,$tel,$email,$end,$bairro,$cidade,$estado,$cep);";
            cmd.Parameters.AddWithValue("$nome",   f.NomeFornecedor);
            cmd.Parameters.AddWithValue("$cnpj",   f.CnpjFornecedor);
            cmd.Parameters.AddWithValue("$tel",    f.TelefoneFornecedor);
            cmd.Parameters.AddWithValue("$email",  f.EmailFornecedor);
            cmd.Parameters.AddWithValue("$end",    f.EnderecoFornecedor);
            cmd.Parameters.AddWithValue("$bairro", f.BairroFornecedor);
            cmd.Parameters.AddWithValue("$cidade", f.CidadeFornecedor);
            cmd.Parameters.AddWithValue("$estado", f.EstadoFornecedor);
            cmd.Parameters.AddWithValue("$cep",    f.CepFornecedor);
            cmd.ExecuteNonQuery();
            using var cmdId = con.CreateCommand();
            cmdId.CommandText = "SELECT last_insert_rowid();";
            return System.Convert.ToInt32(cmdId.ExecuteScalar());
        }

        public void Atualizar(Fornecedor f)
        {
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                UPDATE Fornecedor SET
                    NomeFornecedor     = $nome,
                    CnpjFornecedor     = $cnpj,
                    TelefoneFornecedor = $tel,
                    EmailFornecedor    = $email,
                    EnderecoFornecedor = $end,
                    BairroFornecedor   = $bairro,
                    CidadeFornecedor   = $cidade,
                    EstadoFornecedor   = $estado,
                    CepFornecedor      = $cep
                WHERE CodigoFornecedor = $cod;";
            cmd.Parameters.AddWithValue("$nome",   f.NomeFornecedor);
            cmd.Parameters.AddWithValue("$cnpj",   f.CnpjFornecedor);
            cmd.Parameters.AddWithValue("$tel",    f.TelefoneFornecedor);
            cmd.Parameters.AddWithValue("$email",  f.EmailFornecedor);
            cmd.Parameters.AddWithValue("$end",    f.EnderecoFornecedor);
            cmd.Parameters.AddWithValue("$bairro", f.BairroFornecedor);
            cmd.Parameters.AddWithValue("$cidade", f.CidadeFornecedor);
            cmd.Parameters.AddWithValue("$estado", f.EstadoFornecedor);
            cmd.Parameters.AddWithValue("$cep",    f.CepFornecedor);
            cmd.Parameters.AddWithValue("$cod",    f.CodigoFornecedor);
            cmd.ExecuteNonQuery();
        }
    }
}
