using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using CadastroBD.Modelos;

namespace CadastroBD.Dados
{
    public class ClienteDAO
    {
        public List<Cliente> Listar()
        {
            var lista = new List<Cliente>();
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                SELECT CodigoCliente, NomeCliente, CpfCliente, TelefoneCliente,
                       EmailCliente, EnderecoCliente, BairroCliente, CidadeCliente,
                       EstadoCliente, CepCliente
                FROM Cliente ORDER BY CodigoCliente;";
            using var r = cmd.ExecuteReader();
            while (r.Read())
                lista.Add(new Cliente {
                    CodigoCliente   = r.GetInt32(0),
                    NomeCliente     = r.GetString(1),
                    CpfCliente      = r.IsDBNull(2) ? "" : r.GetString(2),
                    TelefoneCliente = r.IsDBNull(3) ? "" : r.GetString(3),
                    EmailCliente    = r.IsDBNull(4) ? "" : r.GetString(4),
                    EnderecoCliente = r.IsDBNull(5) ? "" : r.GetString(5),
                    BairroCliente   = r.IsDBNull(6) ? "" : r.GetString(6),
                    CidadeCliente   = r.IsDBNull(7) ? "" : r.GetString(7),
                    EstadoCliente   = r.IsDBNull(8) ? "" : r.GetString(8),
                    CepCliente      = r.IsDBNull(9) ? "" : r.GetString(9)
                });
            return lista;
        }

        public int Inserir(Cliente c)
        {
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO Cliente
                    (NomeCliente, CpfCliente, TelefoneCliente, EmailCliente,
                     EnderecoCliente, BairroCliente, CidadeCliente, EstadoCliente, CepCliente)
                VALUES
                    ($nome,$cpf,$tel,$email,$end,$bairro,$cidade,$estado,$cep);";
            cmd.Parameters.AddWithValue("$nome",   c.NomeCliente);
            cmd.Parameters.AddWithValue("$cpf",    c.CpfCliente);
            cmd.Parameters.AddWithValue("$tel",    c.TelefoneCliente);
            cmd.Parameters.AddWithValue("$email",  c.EmailCliente);
            cmd.Parameters.AddWithValue("$end",    c.EnderecoCliente);
            cmd.Parameters.AddWithValue("$bairro", c.BairroCliente);
            cmd.Parameters.AddWithValue("$cidade", c.CidadeCliente);
            cmd.Parameters.AddWithValue("$estado", c.EstadoCliente);
            cmd.Parameters.AddWithValue("$cep",    c.CepCliente);
            cmd.ExecuteNonQuery();
            using var cmdId = con.CreateCommand();
            cmdId.CommandText = "SELECT last_insert_rowid();";
            return System.Convert.ToInt32(cmdId.ExecuteScalar());
        }

        public void Atualizar(Cliente c)
        {
            using SqliteConnection con = Conexao.NovaConexao();
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
                UPDATE Cliente SET
                    NomeCliente     = $nome,
                    CpfCliente      = $cpf,
                    TelefoneCliente = $tel,
                    EmailCliente    = $email,
                    EnderecoCliente = $end,
                    BairroCliente   = $bairro,
                    CidadeCliente   = $cidade,
                    EstadoCliente   = $estado,
                    CepCliente      = $cep
                WHERE CodigoCliente = $cod;";
            cmd.Parameters.AddWithValue("$nome",   c.NomeCliente);
            cmd.Parameters.AddWithValue("$cpf",    c.CpfCliente);
            cmd.Parameters.AddWithValue("$tel",    c.TelefoneCliente);
            cmd.Parameters.AddWithValue("$email",  c.EmailCliente);
            cmd.Parameters.AddWithValue("$end",    c.EnderecoCliente);
            cmd.Parameters.AddWithValue("$bairro", c.BairroCliente);
            cmd.Parameters.AddWithValue("$cidade", c.CidadeCliente);
            cmd.Parameters.AddWithValue("$estado", c.EstadoCliente);
            cmd.Parameters.AddWithValue("$cep",    c.CepCliente);
            cmd.Parameters.AddWithValue("$cod",    c.CodigoCliente);
            cmd.ExecuteNonQuery();
        }
    }
}
