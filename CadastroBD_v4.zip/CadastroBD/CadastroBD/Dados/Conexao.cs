using System;
using System.IO;
using Microsoft.Data.Sqlite;

namespace CadastroBD.Dados
{
    public static class Conexao
    {
        private static readonly string PastaBanco =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Banco");

        private static readonly string CaminhoBanco =
            Path.Combine(PastaBanco, "CadastroBD.db");

        public static string StringConexao => $"Data Source={CaminhoBanco}";

        public static SqliteConnection NovaConexao()
            => new SqliteConnection(StringConexao);

        public static void InicializarBanco()
        {
            if (!Directory.Exists(PastaBanco))
                Directory.CreateDirectory(PastaBanco);

            using SqliteConnection con = NovaConexao();
            con.Open();

            // ── Criação inicial das tabelas ──────────────────────────────
            Exec(con, @"
                CREATE TABLE IF NOT EXISTS Usuario (
                    CodigoUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
                    NomeUsuario   TEXT NOT NULL,
                    NivelUsuario  TEXT NOT NULL,
                    LoginUsuario  TEXT NOT NULL,
                    SenhaUsuario  TEXT NOT NULL
                );");

            Exec(con, @"
                CREATE TABLE IF NOT EXISTS Cliente (
                    CodigoCliente   INTEGER PRIMARY KEY AUTOINCREMENT,
                    NomeCliente     TEXT NOT NULL,
                    CpfCliente      TEXT,
                    TelefoneCliente TEXT,
                    EmailCliente    TEXT,
                    EnderecoCliente TEXT,
                    BairroCliente   TEXT,
                    CidadeCliente   TEXT,
                    EstadoCliente   TEXT,
                    CepCliente      TEXT
                );");

            Exec(con, @"
                CREATE TABLE IF NOT EXISTS Fornecedor (
                    CodigoFornecedor   INTEGER PRIMARY KEY AUTOINCREMENT,
                    NomeFornecedor     TEXT NOT NULL,
                    CnpjFornecedor     TEXT,
                    TelefoneFornecedor TEXT,
                    EmailFornecedor    TEXT,
                    EnderecoFornecedor TEXT,
                    BairroFornecedor   TEXT,
                    CidadeFornecedor   TEXT,
                    EstadoFornecedor   TEXT,
                    CepFornecedor      TEXT
                );");

            // ── Migração: adiciona colunas novas em bancos já existentes ─
            // O SQLite não suporta "ADD COLUMN IF NOT EXISTS", então tentamos
            // e ignoramos o erro se a coluna já existir.
            string[] colsCliente = {
                "BairroCliente TEXT", "CidadeCliente TEXT",
                "EstadoCliente TEXT", "CepCliente TEXT"
            };
            foreach (var col in colsCliente)
                TentarAlter(con, $"ALTER TABLE Cliente ADD COLUMN {col};");

            string[] colsFornecedor = {
                "BairroFornecedor TEXT", "CidadeFornecedor TEXT",
                "EstadoFornecedor TEXT", "CepFornecedor TEXT"
            };
            foreach (var col in colsFornecedor)
                TentarAlter(con, $"ALTER TABLE Fornecedor ADD COLUMN {col};");
        }

        private static void Exec(SqliteConnection con, string sql)
        {
            using var cmd = con.CreateCommand();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Executa ALTER TABLE e ignora silenciosamente se a coluna já existir.
        /// </summary>
        private static void TentarAlter(SqliteConnection con, string sql)
        {
            try { Exec(con, sql); }
            catch (SqliteException) { /* coluna já existe — tudo certo */ }
        }
    }
}
