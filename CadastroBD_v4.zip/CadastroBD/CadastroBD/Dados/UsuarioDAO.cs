using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using CadastroBD.Modelos;

namespace CadastroBD.Dados
{
    /// <summary>
    /// Responsável por toda a conversa com o banco de dados para a tabela Usuario.
    /// </summary>
    public class UsuarioDAO
    {
        public List<Usuario> Listar()
        {
            var lista = new List<Usuario>();

            using SqliteConnection conexao = Conexao.NovaConexao();
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText =
                "SELECT CodigoUsuario, NomeUsuario, NivelUsuario, LoginUsuario, SenhaUsuario " +
                "FROM Usuario ORDER BY CodigoUsuario;";

            using var leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                lista.Add(new Usuario
                {
                    CodigoUsuario = leitor.GetInt32(0),
                    NomeUsuario = leitor.GetString(1),
                    NivelUsuario = leitor.GetString(2),
                    LoginUsuario = leitor.GetString(3),
                    SenhaUsuario = leitor.GetString(4)
                });
            }

            return lista;
        }

        /// <summary>Insere um novo usuário e retorna o código gerado automaticamente.</summary>
        public int Inserir(Usuario usuario)
        {
            using SqliteConnection conexao = Conexao.NovaConexao();
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                INSERT INTO Usuario (NomeUsuario, NivelUsuario, LoginUsuario, SenhaUsuario)
                VALUES ($nome, $nivel, $login, $senha);";
            comando.Parameters.AddWithValue("$nome", usuario.NomeUsuario);
            comando.Parameters.AddWithValue("$nivel", usuario.NivelUsuario);
            comando.Parameters.AddWithValue("$login", usuario.LoginUsuario);
            comando.Parameters.AddWithValue("$senha", usuario.SenhaUsuario);
            comando.ExecuteNonQuery();

            using var comandoId = conexao.CreateCommand();
            comandoId.CommandText = "SELECT last_insert_rowid();";
            return System.Convert.ToInt32(comandoId.ExecuteScalar());
        }

        public void Atualizar(Usuario usuario)
        {
            using SqliteConnection conexao = Conexao.NovaConexao();
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                UPDATE Usuario SET
                    NomeUsuario  = $nome,
                    NivelUsuario = $nivel,
                    LoginUsuario = $login,
                    SenhaUsuario = $senha
                WHERE CodigoUsuario = $codigo;";
            comando.Parameters.AddWithValue("$nome", usuario.NomeUsuario);
            comando.Parameters.AddWithValue("$nivel", usuario.NivelUsuario);
            comando.Parameters.AddWithValue("$login", usuario.LoginUsuario);
            comando.Parameters.AddWithValue("$senha", usuario.SenhaUsuario);
            comando.Parameters.AddWithValue("$codigo", usuario.CodigoUsuario);
            comando.ExecuteNonQuery();
        }
    }
}
